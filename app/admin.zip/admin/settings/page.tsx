'use client';

import { useEffect, useState } from 'react';

import Card from '@components/ui/Card';
import Input from '@components/ui/Input';
import Button from '@components/ui/Button';
import InlineAlert from '@components/ui/InlineAlert';

type BrokerSettings = {
  depositWallet: string;
  updatedAt: string;
  updatedBy: string;
};

export default function AdminSettingsPage() {
  const [depositWallet, setDepositWallet] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch('/api/admin/settings')
      .then(async (r) => {
        if (!r.ok) {
          const data = await r.json().catch(() => ({}));
          throw new Error(data?.error || 'Failed to load settings');
        }
        return r.json();
      })
      .then((data: { settings: BrokerSettings }) => {
        if (cancelled) return;
        setDepositWallet(data.settings.depositWallet || '');
      })
      .catch((e: any) => {
        if (cancelled) return;
        setError(e?.message || 'Failed to load settings');
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  async function onSave() {
    setSaving(true);
    setMessage(null);
    setError(null);

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositWallet }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.error || 'Update failed');
      }

      const data: { settings: BrokerSettings } = await res.json();
      setDepositWallet(data.settings.depositWallet || '');
      setMessage('Deposit wallet updated successfully');
    } catch (e: any) {
      setError(e?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  }

  async function copyWallet() {
    try {
      await navigator.clipboard.writeText(depositWallet);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError('Copy failed (browser blocked clipboard)');
    }
  }

  if (loading) return <div className="text-muted">Loading...</div>;

  return (
    <div className="space-y-4">
      {message && <InlineAlert variant="success">{message}</InlineAlert>}
      {error && <InlineAlert variant="error">{error}</InlineAlert>}

      <Card className="p-6 space-y-4">
        <div>
          <h2 className="text-lg font-semibold">Broker Settings</h2>
          <p className="text-sm text-muted mt-1">
            Configure the deposit wallet address that users will see when they want to deposit funds.
          </p>
        </div>

        <div className="max-w-2xl space-y-4">
          <div>
            <label className="block text-sm mb-1 text-muted">Deposit Wallet Address</label>
            <div className="flex flex-col sm:flex-row gap-2">
              <Input
                placeholder="Enter wallet address (e.g., 0x...)"
                value={depositWallet}
                onChange={(e) => setDepositWallet(e.target.value)}
                className="flex-1 font-mono text-sm"
              />
              <Button variant="secondary" onClick={copyWallet} disabled={!depositWallet}>
                {copied ? 'Copied!' : 'Copy'}
              </Button>
            </div>
            <p className="text-xs text-muted mt-2">
              This wallet address will be shown to all users when they navigate to the deposit section.
            </p>
          </div>

          <Button onClick={onSave} disabled={saving || !depositWallet} loading={saving}>
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold mb-2">Preview</h3>
        <p className="text-sm text-muted mb-3">This is how users will see the deposit information:</p>
        <div className="rounded-xl border border-border bg-surface p-4">
          <p className="text-sm font-medium mb-2">Deposit Address</p>
          <div className="rounded-lg border border-border bg-white p-3 font-mono text-sm break-all">
            {depositWallet || 'No wallet configured'}
          </div>
          <p className="text-xs text-muted mt-2">Copy this address to send your deposit.</p>
        </div>
      </Card>
    </div>
  );
}

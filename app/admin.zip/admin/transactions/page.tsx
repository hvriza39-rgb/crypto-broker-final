'use client';

import { useEffect, useState } from 'react';
import Card from '@components/ui/Card';
import { Table } from '@components/ui/Table';

type Tx = {
  id: string;
  userEmail: string;
  type: 'buy' | 'sell' | 'deposit' | 'withdraw';
  asset: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
};

const mockTx: Tx[] = [
  {
    id: 'tx_1',
    userEmail: 'ada@example.com',
    type: 'buy',
    asset: 'BTC',
    amount: 0.01,
    status: 'completed',
    createdAt: new Date().toISOString(),
  },
];

export default function AdminTransactionsPage() {
  const [rows, setRows] = useState<Tx[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Replace with /api/admin/transactions when backend is ready
    const t = setTimeout(() => {
      setRows(mockTx);
      setLoading(false);
    }, 250);
    return () => clearTimeout(t);
  }, []);

  return (
    <Card className="p-2">
      <Table headers={['ID', 'User', 'Type', 'Asset', 'Amount', 'Status', 'Created']}>
        {loading ? (
          <tr>
            <td className="px-4 py-4 text-muted" colSpan={7}>
              Loading...
            </td>
          </tr>
        ) : rows.length === 0 ? (
          <tr>
            <td className="px-4 py-4 text-muted" colSpan={7}>
              No transactions
            </td>
          </tr>
        ) : (
          rows.map((r) => (
            <tr key={r.id} className="hover:bg-surface">
              <td className="px-4 py-3 font-mono text-xs">{r.id}</td>
              <td className="px-4 py-3">{r.userEmail}</td>
              <td className="px-4 py-3">{r.type}</td>
              <td className="px-4 py-3">{r.asset}</td>
              <td className="px-4 py-3">{r.amount}</td>
              <td className="px-4 py-3">{r.status}</td>
              <td className="px-4 py-3">{new Date(r.createdAt).toLocaleString()}</td>
            </tr>
          ))
        )}
      </Table>
    </Card>
  );
}

import React from 'react';
import AdminSidebar from '@components/admin/AdminSidebar';
import AdminHeader from '@components/admin/AdminHeader';

export const metadata = {
  title: 'Admin',
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bg flex">
      <aside className="w-64 border-r border-border bg-surface hidden md:block">
        <AdminSidebar />
      </aside>
      <main className="flex-1 min-w-0">
        <AdminHeader />
        <div className="p-4 md:p-6">{children}</div>
      </main>
    </div>
  );
}

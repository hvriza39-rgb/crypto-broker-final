'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Card from '@components/ui/Card';
import Input from '@components/ui/Input';
import Select from '@components/ui/Select';
import InlineAlert from '@components/ui/InlineAlert';
import { Table } from '@components/ui/Table';

type Row = {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  country?: string;
  balance: number;
  kycStatus: string;
  accountStatus: string;
  createdAt: string;
};

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [kyc, setKyc] = useState('');
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (search) p.set('search', search);
    if (status) p.set('status', status);
    if (kyc) p.set('kyc', kyc);
    return p.toString();
  }, [search, status, kyc]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch(`/api/admin/users?${query}`)
      .then(async (r) => {
        if (!r.ok) {
          const data = await r.json().catch(() => ({}));
          throw new Error(data?.error || 'Failed to load users');
        }
        return r.json();
      })
      .then((data) => {
        if (cancelled) return;
        setRows(data.users || []);
      })
      .catch((e: any) => {
        if (cancelled) return;
        setError(e?.message || 'Failed to load users');
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [query]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <Input
            label="Search"
            placeholder="Email, phone, name"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <Select label="Account status" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="closed">Closed</option>
          </Select>

          <Select label="KYC status" value={kyc} onChange={(e) => setKyc(e.target.value)}>
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="verified">Verified</option>
            <option value="rejected">Rejected</option>
          </Select>
        </div>
      </Card>

      {error && <InlineAlert variant="error">{error}</InlineAlert>}

      <Card className="p-2">
        <Table
          headers={['Full name', 'Email', 'Phone', 'Country', 'Balance', 'KYC', 'Status', 'Created', '']}
        >
          {loading ? (
            <tr>
              <td className="px-4 py-4 text-muted" colSpan={9}>
                Loading...
              </td>
            </tr>
          ) : rows.length === 0 ? (
            <tr>
              <td className="px-4 py-4 text-muted" colSpan={9}>
                No users found
              </td>
            </tr>
          ) : (
            rows.map((r) => (
              <tr key={r.id} className="hover:bg-surface">
                <td className="px-4 py-3">{r.fullName}</td>
                <td className="px-4 py-3">{r.email}</td>
                <td className="px-4 py-3">{r.phone || '-'}</td>
                <td className="px-4 py-3">{r.country || '-'}</td>
                <td className="px-4 py-3">
                  {r.balance.toLocaleString(undefined, { style: 'currency', currency: 'USD' })}
                </td>
                <td className="px-4 py-3">{r.kycStatus}</td>
                <td className="px-4 py-3">{r.accountStatus}</td>
                <td className="px-4 py-3">{new Date(r.createdAt).toLocaleString()}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/users/${r.id}`} className="text-accent hover:underline">
                    View
                  </Link>
                </td>
              </tr>
            ))
          )}
        </Table>
      </Card>
    </div>
  );
}
